art'otel Sous Chef Try Day — Current Image Export

Images: 38
Created: 2026-09-19 (replaces the earlier export of the same day)

The images directory preserves each file's project-relative path. This export
holds every image the app ships:

- public/favicon.png, public/favicon.svg and src/assets/artotel-logo.png: brand marks.
- src/assets/kitchen/*.jpg: the generated isometric kitchen map, the illustrated
  goods-in and events backdrops (still waiting for photographs), the fish box
  and the delivery crates.
- src/assets/kitchen/photos/*.webp: the client photographs of Terence received
  on 19 September 2026 (welcome hero, briefing circle, dialogue avatar, pass,
  fridges and bench backdrops), exported as WebP. The originals stay in
  attached_assets/.
- src/assets/kitchen/inspections/videos/*.webp: poster frames of the 14 approved
  fridge inspection clips. The clips themselves are video and are not included.

Not included, because they were deleted from the project on 19 September 2026:
the generated pass, corridor and bench scenes, the five character portraits,
the intro photo and the eight earlier fridge stills (all replaced by the
photographs and clips); the fridge, freezer and walk-in interior pictures that
only the retired handover pass and corridor scenes used; and the stock
ingredient photographs that had been held for a superseded version of the
goods-in scene, which never reached the app.
