art'otel Sous Chef Try Day — Current Image Export

Images: 36
Created: 2026-09-18

The images directory preserves each file's project-relative path.
