art'otel Sous Chef Try Day — Current Image Export

Images: 41
Created: 2026-09-19 (replaces the export of 2026-09-18)

The images directory preserves each file's project-relative path. This export
holds every image the app ships:

- public/favicon.png, public/favicon.svg and src/assets/artotel-logo.png: brand marks.
- src/assets/kitchen/*.jpg: the generated isometric kitchen map, the illustrated
  goods-in and events backdrops (still waiting for photographs), the fridge,
  freezer and walk-in interiors, the fish box and the delivery crates.
- src/assets/kitchen/photos/*.webp: the client photographs of Terence received
  on 19 September 2026 (welcome hero, briefing circle, dialogue avatar, pass,
  fridges and bench backdrops), exported as WebP. The originals stay in
  attached_assets/.
- src/assets/kitchen/inspections/videos/*.webp: poster frames of the 14 approved
  fridge inspection clips. The clips themselves are video and are not included.

Not included: the generated pass, corridor and bench scenes, the five character
portraits, the intro photo and the eight earlier fridge stills. The photographs
and clips replaced them and they were deleted from the project on 19 September
2026. Also not included: the stock ingredient photographs under
src/assets/delivery-photos/, which belong to a goods-in redesign that is not
wired into the app.
